/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment;

/**
 *
 * @author Bruh
 */
public class Customer extends User {
    private double currentMoney;
    public Customer(String userID, String username, String userPw, String userEmail)
    {
        super(userID, username, userPw, userEmail);
    }
}

